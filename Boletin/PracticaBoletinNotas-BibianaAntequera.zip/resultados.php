<?php
    $notas = array("mates" => array("trimestres" => array("trim1" => "3",
                    "trim2" => "10",
                    "trim3" => "7")),
        "lengua" => array("trimestres" => array("trim1" => "8",
                    "trim2" => "5",
                    "trim3" => "3")),
        "fisica" => array("trimestres" => array("trim1" => "7",
                    "trim2" => "2",
                    "trim3" => "1")),
        "latin" => array("trimestres" => array("trim1" => "4",
                    "trim2" => "7",
                    "trim3" => "8")),
        "ingles" => array("trimestres" => array("trim1" => "6",
                    "trim2" => "2",
                    "trim3" => "3")));
?>